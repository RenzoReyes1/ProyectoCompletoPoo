
import java.sql.Connection;
import java.sql.DriverManager;



/**
 *
 * @author dlchh
 */
public class Conexion {
   
    public static final String  URL = "jdbc:mysql://localhost:3306/Prueba";
    public static final String  USERNAME = "root";
    public static final String  PASSWORD = "123456";

    public static Connection getConexion(){
        Connection con  = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = (Connection) DriverManager.getConnection(URL,USERNAME,PASSWORD);
            System.out.println("CONEXION A LA BASE DE DATOS EXITOSA");
            return con;

        }
        catch(Exception SQLException){
            System.out.println(SQLException);
             return null;
        }
    }
}
